package org.npu.orderapp.test;

import org.junit.Test;
import org.npu.orderapp.domain.OrderItem;
import org.npu.orderapp.exceptions.OrderItemException;

public class OrderItemTest {
	private OrderItem orderItem = new OrderItem () ;
	
	@Test (expected =OrderItemException.class)
	public void testQuantity () throws Exception{
		
		int quantity = 20;
		orderItem.setQuantity(quantity);
		
	}
	
}
