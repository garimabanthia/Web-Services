package org.npu.orderapp.test;

import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;
import org.npu.orderapp.domain.Customer;
import org.npu.orderapp.domain.Order;
import org.npu.orderapp.exceptions.TaxServiceException;
import org.npu.orderapp.exceptions.OrderException;
import org.npu.orderapp.services.TaxService;
import org.npu.orderapp.services.TaxServiceImpl;

public class OrderTest {
	private Order order = new Order("123");
	private TaxServiceImpl taxService = new TaxServiceImpl();

	@Test
	public void testOrderCode() {
		String tstCode = new String("A4535");
		order.setCode("A123");
		String expCode = order.getCode();
		Assert.assertNotSame(expCode, tstCode);
	}
	@Test(expected=OrderException.class)
	public void testsetSubtotal()throws Exception
	{
		double subtotal = -1.0;
		order.setSubtotal(subtotal);
	}
	
	@Test
	public void testCustomer(){
		int id = 2;
		Customer customer = new Customer();
		customer.setId(id);
		order.setCustomer(customer);		
        }
	
	
}
