package org.npu.orderapp.test;

import org.junit.Assert;
import org.junit.Test;
import org.npu.orderapp.domain.Order;
import org.npu.orderapp.services.TaxService;
import org.npu.orderapp.services.TaxServiceImpl;

public class TaxServiceTest {
	private Order order = new Order("A6774");
	TaxService taxService= new TaxServiceImpl();
	//public TaxServiceTest(){}
	@Test(expected=NullPointerException.class)
	public void testComputeTax() throws Exception
	{
		double tax =taxService.computeTax(order);
		Assert.assertNotNull(tax);
	}
}
