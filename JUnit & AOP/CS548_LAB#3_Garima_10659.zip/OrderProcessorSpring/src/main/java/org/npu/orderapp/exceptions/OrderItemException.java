package org.npu.orderapp.exceptions;

public class OrderItemException extends Exception{
	public OrderItemException(String msg) {
		super(msg);
	}

}
