package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;

public interface OrderProcessorService {
	//public  double computeTax(Order order) ;
	public void newOrder(Order order) ;
}