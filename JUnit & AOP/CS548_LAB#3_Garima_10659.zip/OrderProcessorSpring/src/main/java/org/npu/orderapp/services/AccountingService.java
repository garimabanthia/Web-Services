package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;



public interface AccountingService {
	public void recordNewOrder(Order order);
	public double ComputeTax(Order order);
}
