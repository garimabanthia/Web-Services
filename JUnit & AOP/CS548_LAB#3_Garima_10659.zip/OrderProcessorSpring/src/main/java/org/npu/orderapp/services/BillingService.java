package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;
 
public interface BillingService {
	public void billCustomer(Customer cus, Order order);
}
