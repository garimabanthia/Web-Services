package org.npu.orderapp.exceptions;

public class TaxServiceException extends Exception{
	public TaxServiceException(String msg) {
		super(msg);
	}

}
