package org.npu.orderapp.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.jboss.logging.Logger;


public class Logging {
	@Aspect
	public class LoggingAspects {
	private Logger logger = Logger.getLogger(LoggingAspects.class);

	@Before("execution(* org.npu.orderapp.services.OrderProcessorServiceImpl.newOrder(..))")
	public void logBeforeMethods(JoinPoint joinPt)
	{
		Object methodArgs[];
		int argCnt;
		logger.debug("*********Log Before called*********");
		logger.debug("Logging Method's signature : " +joinPt.getSignature());
		methodArgs=joinPt.getArgs();
		argCnt = 1;
		for(Object methodArg:methodArgs)
		{
			logger.debug("Method arg :"+" "+argCnt+":"+methodArg);
			argCnt++;
		}
		logger.debug(" ");
	}
	@After("execution(* org.npu.orderapp.services.OrderProcessorServices.newOrder(..))")
	public void logAfter(JoinPoint joinPt)
	{	Object methodArgs[];
		logger.debug("*********Log After advice called*********");
		logger.debug("Logging Methods :" +joinPt.getSignature());
		methodArgs=joinPt.getArgs();
		
		for(Object methodArg:methodArgs)
		{
		logger.debug("Method arg :"+methodArg);
		}
		logger.debug(" ");
	}
	@Around("execution(* org.npu.orderapp.services.AccountingServiceImpl.ComputeTax(..))")
	public Object logAroundNewOrder(ProceedingJoinPoint joinPoint)throws Throwable {
		Object result;
		logger.debug("*********Log Around New Order*********");
		logger.debug("Starting Method :"+joinPoint.getSignature());
		try{
		result = joinPoint.proceed(); //continue on the intercepted method
		logger.debug("Returned value :"+result);
		logger.debug(" ");
		return result;
		}catch(IllegalArgumentException ex)
		{
			logger.debug("Method throwed exception :"+ex);
			throw ex;
		}
		
	}
	}
}
