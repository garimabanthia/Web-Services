package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;

public interface InventoryService {
	
	public void adjustInventory(Order order);
	public void printCurrentInventory();
}
