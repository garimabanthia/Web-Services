package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class AccountingServiceImpl implements AccountingService {

	private TaxService taxService;
	
	@Autowired
	public AccountingServiceImpl(TaxService taxService) {
		this.taxService = taxService;
	}

	public void recordNewOrder(Order order) {

	}
	
	

	public double ComputeTax(Order order) {

		return taxService.computeTax(order);

	}
}
