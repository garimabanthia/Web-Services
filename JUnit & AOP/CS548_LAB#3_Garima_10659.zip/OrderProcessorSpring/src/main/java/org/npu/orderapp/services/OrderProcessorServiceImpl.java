package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class OrderProcessorServiceImpl implements OrderProcessorService {
	private final  AccountingService acctService;
	private final InventoryService inventoryService;

	
	@Autowired
	public OrderProcessorServiceImpl( AccountingService acctService,InventoryService inventoryService) {
		this.acctService = acctService;
		this.inventoryService = inventoryService;
	}

	
	public void newOrder(Order order) {
		// acctService.recordNewOrder(order);

		double tax = 0.0, total, subTotal = 0.0;
		tax = acctService.ComputeTax(order);
//		System.out.println("TAX = " + tax);
		order.setTax(tax);

		subTotal = order.getSubtotal();
//		System.out.println("SUBTOTAL = " + subTotal);
		
		total = subTotal + tax;
//		System.out.println("TOTAL = " + total);

		order.setTotal(total);

		inventoryService.adjustInventory(order);

	}
	
	public void OrderitemException(){
		
		 int x = 5 / 0;	
	}
}