package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;

import org.springframework.beans.factory.annotation.Autowired;

public interface TaxService {
	public  double computeTax(Order order) ;

}