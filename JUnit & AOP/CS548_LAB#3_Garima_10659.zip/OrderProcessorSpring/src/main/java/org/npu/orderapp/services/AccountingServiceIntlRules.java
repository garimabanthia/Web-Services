package org.npu.orderapp.services;
 import org.npu.orderapp.domain.*;

import org.springframework.stereotype.Component;


@Component("acctServiceIntlRules")
public class AccountingServiceIntlRules { //implements AccountingService{ 

	public void recordNewOrder(Order order) {
		System.out.println("Applying International Accounting Rules");
		return;
	}


}
