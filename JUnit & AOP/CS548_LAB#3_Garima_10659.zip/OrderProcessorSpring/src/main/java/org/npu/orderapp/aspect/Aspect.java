package org.npu.orderapp.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.jboss.logging.Logger;

public class Aspect {
	
	private Logger logger = Logger.getLogger(Aspect.class);
	@AfterReturning (pointcut ="execution(* org.npu.orderapp.services.AccountingServiceImpl.ComputeTax(..))", returning = "result")
	public void logAfterReturning(JoinPoint joinPoint, double result) {
		logger.debug("****** Log After Returning() executed *********");
		logger.debug("Method signature: "+joinPoint.getSignature());
		logger.debug("Calculating tax using " + joinPoint.getSignature().getName()+" method");
		logger.debug("Returned Value is :"+result);		
		logger.debug(" ");
	}
	

@AfterThrowing(pointcut ="execution(public * org.npu.orderapp.services.OrderProcessorServiceImpl.OrderitemException(..))", throwing = "ex")
	    public void logOrderItemAfterThrowing(JoinPoint joinPoint,Exception ex) {
		logger.debug("********* Log Order Item After Throwing() executed *******************");
		logger.debug("Exception"+" "+ex+"was thrown in"+" "+ joinPoint.getSignature());	
		logger.debug(" ");
		
	 
	    }


			
}
